package com.hamzaahmed0196.datacollectionfordrinking.presentation.activityModel

data class ActivityModelTwo(val name : String)
