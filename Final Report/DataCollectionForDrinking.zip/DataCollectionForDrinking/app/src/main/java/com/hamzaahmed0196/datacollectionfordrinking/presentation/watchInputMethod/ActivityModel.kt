package com.hamzaahmed0196.datacollectionfordrinking.presentation.watchInputMethod

data class ActivityModel(val image : Int, val name : String)
